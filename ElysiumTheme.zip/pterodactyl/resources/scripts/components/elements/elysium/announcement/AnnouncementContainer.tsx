import styled from 'styled-components/macro';
import tw from 'twin.macro';

const AnnouncementContainer = styled.div`
    ${tw`flex items-center rounded-2xl shadow px-4 py-3 m-4 text-white`}
`;

export default AnnouncementContainer;